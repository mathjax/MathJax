/*
 *  /MathJax/fonts/HTML-CSS/TeX/png/Main/Italic/LatinExtendedA.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Unpack([
  ['MathJax.OutputJax["HTML-CSS"].','defineImageData({"MathJax_Main-italic":{305:[[3,3,0],[3,4,0],[4,4,0],[4,5,0],[5,6,0],[6,7,0],[7,9,0],[8,10,0],[10,12,0],[12,15,0],[14,17,0],[16,22,1],[19,26,1],[23,30,1]]}});MathJax.Ajax.loadComplete(',0,'imgDir+"/Main/Italic"+',0,'imgPacked+"/LatinExtendedA.js");']
]);

